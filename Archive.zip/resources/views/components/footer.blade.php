<footer class="footer" style="text-align: center; padding: 15px 0; background-color: #f8f9fa;">
    <p style="margin: 0; font-size: 20px;">
        Sistem Manajemen Bank Sampah | Repost by
        <a href="https://siblih.rf.gd" target="_blank" rel="noopener noreferrer">SIBLIH</a>
    </p>
</footer>


